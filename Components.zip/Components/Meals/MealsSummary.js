
import classes from './MealsSummary.module.css'


const MealsSummary = ()=>{
    return (
            <section className={classes.summary}>
                <h2>Delicious Food , Delievered To You</h2>
                <p>Choose your meals according to your need and we can very it</p>
                <p>Choose your meals according to your need and we can very it nd sfdsbf </p>
            </section>
    )
}

export default MealsSummary;